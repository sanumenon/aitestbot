package com.charitableimpact;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.testng.*;
import org.testng.annotations.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.charitableimpact.config.ExtentReportManager;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DashboardTest {
    WebDriver driver;
    ExtentTest test;

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
    }

    @Test
    public void dashboardTest1() {
        ExtentTest test = ExtentReportManager.createTest("Dashboard Test 1");
        test.log(Status.INFO, "Navigating to the dashboard page");

        driver.get("https://my.stg.charitableimpact.com/users/login/dashboard");

        DashboardPage dashboardPage = new DashboardPage(driver);
        // Perform actions on the dashboard page as required

        test.log(Status.PASS, "Dashboard test 1 completed");
    }

    @Test
    public void dashboardTest2() {
        ExtentTest test = ExtentReportManager.createTest("Dashboard Test 2");
        test.log(Status.INFO, "Navigating to the dashboard page");

        driver.get("https://my.stg.charitableimpact.com/users/login/dashboard");

        DashboardPage dashboardPage = new DashboardPage(driver);
        // Perform different actions on the dashboard page as required

        test.log(Status.PASS, "Dashboard test 2 completed");
    }

    @Test
    public void dashboardTest3() {
        ExtentTest test = ExtentReportManager.createTest("Dashboard Test 3");
        test.log(Status.INFO, "Navigating to the dashboard page");

        driver.get("https://my.stg.charitableimpact.com/users/login/dashboard");

        DashboardPage dashboardPage = new DashboardPage(driver);
        // Perform additional actions on the dashboard page as required

        test.log(Status.PASS, "Dashboard test 3 completed");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}