package com.charitableimpact;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

public class EditPage {
    WebDriver driver;

    public EditPage(WebDriver driver) {
        this.driver = driver;
    }

    
}