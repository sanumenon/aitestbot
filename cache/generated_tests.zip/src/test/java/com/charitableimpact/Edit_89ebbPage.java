package com.charitableimpact;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

public class Edit_89ebbPage {
    WebDriver driver;

    public Edit_89ebbPage(WebDriver driver) {
        this.driver = driver;
    }

    
}