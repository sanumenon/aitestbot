package com.charitableimpact;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

public class Edit_de4bePage {
    WebDriver driver;

    public Edit_de4bePage(WebDriver driver) {
        this.driver = driver;
    }

    
}