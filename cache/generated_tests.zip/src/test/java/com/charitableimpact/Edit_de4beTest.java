package com.charitableimpact;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.*;
import com.charitableimpact.config.ExtentReportManager;
import com.charitableimpact.Edit_de4bePage;


import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import io.github.bonigarcia.wdm.WebDriverManager;


public class Edit_de4beTest {
    public WebDriver driver;
    ExtentReports extent;
    ExtentTest test;

    @BeforeClass
    public void setup() {
        extent = ExtentReportManager.getInstance();
        
        
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        /*options.addArguments("--headless", "--no-sandbox", "--disable-dev-shm-usage");*/
        driver = new ChromeDriver(options);
        

        driver.manage().window().maximize();
        driver.get("https://my.charitableimpact.com/users/login");
        new File("screenshots").mkdirs();
    }

    @Test
    public void testEdit_de4be() {
        test = extent.createTest("Edit_de4be Test");
        SoftAssert softAssert = new SoftAssert();
        Edit_de4bePage page = new Edit_de4bePage(driver);

        

        

        softAssert.assertAll();
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
        extent.flush();
    }
}