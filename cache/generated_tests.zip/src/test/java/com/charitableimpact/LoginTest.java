package com.charitableimpact;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.testng.*;
import org.testng.annotations.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.charitableimpact.config.ExtentReportManager;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {
    private WebDriver driver;
    ExtentTest test;

    @BeforeClass
    public void setUp() {
        ExtentReports extent = ExtentReportManager.getExtent();
        test = ExtentReportManager.createTest("Login Test");

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://my.charitableimpact.com/users/login");
    }

    @Test
    public void testLogin() {
        LoginPage loginPage = new LoginPage(driver);

        test.log(Status.INFO, "Entering login credentials");
        loginPage.enterEmail("menon.sanu@gmail.com");
        loginPage.enterPassword("Test123#");

        test.log(Status.INFO, "Clicking on Login button");
        loginPage.clickLoginButton();

        // Add assertions or further steps as needed
    }

    // Add @AfterClass method to quit driver and flush extent reports
}