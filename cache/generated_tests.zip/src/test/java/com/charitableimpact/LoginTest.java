package com.charitableimpact;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.testng.*;
import org.testng.annotations.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.charitableimpact.config.ExtentReportManager;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {
    WebDriver driver;
    ExtentTest test;

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
    }

    @Test
    public void loginTest() {
        ExtentTest test = ExtentReportManager.createTest("Login Test");
        test.log(Status.INFO, "Starting the login test");

        driver.get("https://my.stg.charitableimpact.com/users/login/dashboard");

        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterEmail("bal.ganesh001@gmail.com");
        loginPage.enterPassword("Test123#");
        loginPage.clickSubmitButton();
        
        test.log(Status.PASS, "Login successful");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}