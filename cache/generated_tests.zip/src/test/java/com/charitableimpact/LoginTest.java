package com.charitableimpact;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.testng.*;
import org.testng.annotations.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.charitableimpact.config.ExtentReportManager;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {
    private WebDriver driver;
    private LoginPage loginPage;
    private ExtentTest test;

    @BeforeClass
    public void setup() {
        ExtentReports extent = ExtentReportManager.getExtent();
        test = extent.createTest("Login Test");

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        loginPage = new LoginPage(driver);
        driver.get("https://my.stg.charitableimpact.com/users/login/dashboard");
        test.log(Status.INFO, "Navigated to login page.");
    }

    @Test
    public void testLogin() {
        test = ExtentReportManager.createTest("Login Test");
        loginPage.login("bal.ganesh001@gmail.com", "Test123#");
        test.log(Status.INFO, "Entered login credentials and submitted.");
    }

    @Test(dependsOnMethods = "testLogin")
    public void testDashboardPage() {
        test = ExtentReportManager.createTest("Dashboard Page Test");
        // Add test steps for dashboard page here
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
        ExtentReportManager.flush();
    }
}