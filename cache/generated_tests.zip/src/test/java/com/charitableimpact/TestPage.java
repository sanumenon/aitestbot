package com.charitableimpact;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

public class TestPage {
    WebDriver driver;

    public TestPage(WebDriver driver) {
        this.driver = driver;
    }

    
}