package com.charitableimpact;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

public class Test_0ee4ePage {
    WebDriver driver;

    public Test_0ee4ePage(WebDriver driver) {
        this.driver = driver;
    }

    
}